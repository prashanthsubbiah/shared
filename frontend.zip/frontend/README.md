## Cleanup and refactor

Components have been moved to relevant directories
Cleanup with respect to readability, syntax and ES6 changes are done
Tests have been written for two components (Jest and Enzyme are used)

## API Integration

`cones` data has been moved from webpack level to node.js server at `/api/cones/` endpoint.

## Add new feature

New feature has been implemented. System accepts a new input `capital` from user and responds instantly to the new value
App will also have a new look and feel via material design UI

## Packages used

Jest and Enzyme - Unit testing
@material-ui - UI Look and feel
Express - Node.js express framework for the web server
axios - For HTTP calls
prettier - For opinionated code formatter