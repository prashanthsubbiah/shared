import React from "react";
import PropTypes from "prop-types";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";

class RiskLevelSelector extends React.Component {
  constructor(props) {
    super(props);
    this.onChange = this.onChange.bind(this);
  }

  onChange(event) {
    let { onChangeRiskLevel } = this.props;
    const riskLevel = parseInt(event.target.value);
    onChangeRiskLevel(riskLevel);
  }

  render() {
    const { minRiskLevel, maxRiskLevel } = this.props;
    const defultRiskl = 3;
    const options = [];
    for (let k = minRiskLevel; k <= maxRiskLevel; ++k) {
      options.push(
        <MenuItem key={k} value={k}>
          {k}
        </MenuItem>
      );
    }

    return (
      <React.Fragment>
        <p
          style={{
            fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
            display: "inline-block",
            marginRight: "10px"
          }}
        >
          Risk level:
        </p>
        <Select onChange={this.onChange} defaultValue={defultRiskl}>
          {options}
        </Select>
      </React.Fragment>
    );
  }
}

RiskLevelSelector.defaultProps = {
  minRiskLevel: 3,
  maxRiskLevel: 25,
  onChangeRiskLevel: () => {}
};

RiskLevelSelector.propTypes = {
  minRiskLevel: PropTypes.number,
  maxRiskLevel: PropTypes.number,
  onChangeRiskLevel: PropTypes.func
};

export default RiskLevelSelector;
