import React from "react";
import axios from "axios";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Menu from "./modules/menu";
import RiskLevelSelector from "./common/risk-level-selector";
import Table from "./modules/table";
import Chart from "./modules/chart";
import CircularProgress from "@material-ui/core/CircularProgress";
import TextField from "@material-ui/core/TextField";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      riskLevel: 3,
      data: [],
      loading: false,
      capital: 10000
    };
    this.onChangeRiskLevel = this.onChangeRiskLevel.bind(this);
    this.onChangeCapital = this.onChangeCapital.bind(this);
  }

  onChangeRiskLevel(riskLevel) {
    this.setState({ riskLevel });
  }

  onChangeCapital(e) {
    this.setState({ capital: e.target.value });
  }

  componentWillMount() {
    this.setState({ loading: true });
    axios.get("/api/cones").then(response => {
      const { data } = response;
      this.setState({ data, loading: false });
    });
  }

  render() {
    const { riskLevel, loading, data, capital } = this.state;
    const capitalValue = capital ? parseInt(capital) : 0;
    return (
      <Router>
        {loading ? (
          <CircularProgress />
        ) : (
          <div>
            <Menu />
            <div
              style={{ maxWidth: "800px", margin: "0 auto", marginTop: "10px" }}
            >
              <TextField
                style={{ display: "inline-block" }}
                id="standard-basic"
                label="Capital"
                value={capital}
                onChange={this.onChangeCapital}
              />
              <RiskLevelSelector onChangeRiskLevel={this.onChangeRiskLevel} />
              {capitalValue ? (
                <>
                  <Route
                    exact
                    path="/"
                    component={() => (
                      <Table
                        data={data}
                        capital={capitalValue}
                        riskLevel={riskLevel}
                      />
                    )}
                  />
                  <Route
                    path="/table"
                    component={() => (
                      <Table
                        data={data}
                        capital={capitalValue}
                        riskLevel={riskLevel}
                      />
                    )}
                  />
                  <Route
                    path="/chart"
                    component={() => (
                      <Chart
                        data={data}
                        capital={capitalValue}
                        riskLevel={riskLevel}
                      />
                    )}
                  />
                </>
              ) : (
                <p
                  style={{
                    color: "red",
                    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif'
                  }}
                >
                  Please enter a valid capital
                </p>
              )}
            </div>
          </div>
        )}
      </Router>
    );
  }
}
