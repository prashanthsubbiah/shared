import React from 'react';
import { mount } from 'enzyme';
import Table from "./table";

describe('Table Component Tests', () => {
   it('renders with all props', () => {
   	  const data = [{"riskLevel":3,"mu":0.0216,"sigma":0.0215}],
      wrapper = mount(<Table data={data} capital={1000} />);
	  expect(wrapper.find('tbody tr')).toHaveLength(121);
   });

   it('renders without data', () => {
      const wrapper = mount(<Table data={[]} capital={1000} />);
      expect(wrapper.find('tbody tr')).toHaveLength(0);
   });

   it('renders without capital', () => {
      const wrapper = mount(<Table data={[]} capital={0} />);
      expect(wrapper.find('tbody tr')).toHaveLength(0);
   });

   it('renders without any props', () => {
      const wrapper = mount(<Table />);
      expect(wrapper.find('tbody tr')).toHaveLength(0);
   });
});