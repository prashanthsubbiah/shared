const React = require("react");
import PropTypes from "prop-types";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import { calculateTimeSeries } from "../utils";

class TableComponent extends React.Component {
  render() {
    const { riskLevel, capital, data } = this.props;
    const conesArr = data.filter(cone => cone.riskLevel == riskLevel);
    const cone = conesArr && conesArr.length ? conesArr[0] : null;
    const fee = 0.01;
    if (!cone) {
      return <></>;
    }
    const timeSeries = calculateTimeSeries({
      mu: cone.mu,
      sigma: cone.sigma,
      years: 10,
      initialSum: capital,
      monthlySum: 200,
      fee
    });

    const months = timeSeries.median.map((v, idx) => idx);
    const dataGood = timeSeries.upper95.map(v => v.y);
    const dataMedian = timeSeries.median.map(v => v.y);
    const dataBad = timeSeries.lower05.map(v => v.y);

    const rows = months.map((entry, idx) => (
      <TableRow component="tr" scope="row" key={idx}>
        <TableCell>{entry}</TableCell>
        <TableCell>{dataGood[idx]}</TableCell>
        <TableCell>{dataMedian[idx]}</TableCell>
        <TableCell>{dataBad[idx]}</TableCell>
      </TableRow>
    ));

    const tableHeader = React.createElement("tr", {}, [
      React.createElement("th", { key: "month" }, "month"),
      React.createElement("th", { key: "good" }, "good"),
      React.createElement("th", { key: "median" }, "median"),
      React.createElement("th", { key: "bad" }, "bad")
    ]);

    return (
      <TableContainer style={{ minWidth: 650 }} component={Paper}>
        <Table aria-label="simple table">
          <TableHead styles={{ fontWeight: "bold" }}>
            <TableRow>
              <TableCell>Month</TableCell>
              <TableCell>Good</TableCell>
              <TableCell>Median</TableCell>
              <TableCell>Bad</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>{rows}</TableBody>
        </Table>
      </TableContainer>
    );
  }
}

TableComponent.defaultProps = {
  riskLevel: 3,
  data: [],
  capital: 0
};

TableComponent.propTypes = {
  riskLevel: PropTypes.number,
  data: PropTypes.array,
  capital: PropTypes.number
};

export default TableComponent;
