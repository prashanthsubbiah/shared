import React from "react";
import { Link } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";

export default class Menu extends React.Component {
  constructor() {
    super();
    this.state = {
      activeTab: 0
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event, value) {
    this.setState({ activeTab: value });
  }

  render() {
    const { activeTab } = this.state;
    return (
      <AppBar position="static">
        <Tabs
          value={activeTab}
          onChange={this.handleChange}
          aria-label="simple tabs example"
        >
          <Tab value={0} label="Table" component={Link} to="/table"></Tab>
          <Tab value={1} label="Chart" component={Link} to="/chart"></Tab>
        </Tabs>
      </AppBar>
    );
  }
}
