const express = require('express');
const app = express();
const data = require('./cones.json');

app.get('/api/cones', (req, res) => {
	res.json({success: true, data});
});

app.listen(3000);