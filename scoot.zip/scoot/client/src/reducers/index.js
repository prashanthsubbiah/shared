import { combineReducers } from 'redux';
import markers from './reducer-markers';
export default combineReducers({
  markers
});
