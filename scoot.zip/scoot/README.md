## Steps to run

1. Issue `npm install` command both on the root and client folder to have all the dependencies installed
2. Issue `npm start` from the root directory to start application on development mode
3. Hit mock api `/api/mock`
4. Play around with the UI

## DB Details

Have used mongodb for the data storage
`scoot` is the database name and `markers` is the collection name

## API Details

`/api/mock` - Hit this endpoint to add all mock scooters to the map
`/api/markers` - Gets all the scooters to the map (without any restrictions)
`/api/calc` - Gets all the scooters around users location (latitude/longitude) within a range of inputted radius

## Google maps setup

Open `client/src/config.json` and add the Google Maps API key.

## UI Assist

1. Wait for the UI to load all scooters in the map
2. Click on search button and enter parameters to get closest x scooters within y meters of a given lat,lon
3. Can modify parameters and check other behavior

### Note: 
Scooter number if left empty would return all scooters in the entered radius range
Search parameters are prefilled for the ease of testing