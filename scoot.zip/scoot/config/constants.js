'user strict';

module.exports = {
    API_KEY: "AIzaSyAyphEg6Ezze8PuQwfcVAn9e8S56BlEQM8",
    GMAPS_URL: "https://maps.googleapis.com/maps/api"
}